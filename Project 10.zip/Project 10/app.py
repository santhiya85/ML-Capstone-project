import streamlit as st
import joblib
import re
import numpy as np

# Load the saved model, vectorizer, and selector
model = joblib.load(r"C:\Users\binu\OneDrive\Pictures\Desktop\Project 10\model\final_model.pkl")
vectorizer = joblib.load(r"C:\Users\binu\OneDrive\Pictures\Desktop\Project 10\model\tfidf_vectorizer.pkl")
selector = joblib.load(r"C:\Users\binu\OneDrive\Pictures\Desktop\Project 10\model\feature_selector.pkl")

# Text normalization function
def normalize_text(text):
    text = text.lower()
    text = re.sub(r'[^a-z\s]', '', text)
    return text.strip()

# Streamlit UI
st.set_page_config(page_title="Intensity Emotion Classifier", page_icon="💬", layout="wide")

st.markdown(
    """
    <div style="background-color:#e6f2ff;padding:15px;border-radius:10px">
    <h1 style="color:#003366;text-align:center;">Text Intensity Emotion Classifier 🔍</h1>
    </div>
    """, unsafe_allow_html=True
)

st.write("### Enter a message to analyze the intensity of emotion:")

user_input = st.text_area("Text Input", height=150)

if st.button("Predict"):
    if user_input:
        normalized = normalize_text(user_input)
        vectorized = vectorizer.transform([normalized])
        selected_features = selector.transform(vectorized)
        prediction = model.predict(selected_features)

        # Map label to emotion
        label_map = {
            0: ("Happiness", "😊"),
            1: ("Angriness", "😠"),
            2: ("Sadness", "😢")
        }
        emotion, emoji = label_map.get(prediction[0], ("Unknown", "❓"))
        st.success(f"### Predicted Emotion Intensity: {emotion} {emoji}")
    else:
        st.warning("Please enter some text to analyze.")

# Sidebar info
st.sidebar.header("📘 About this App")
st.sidebar.write(
    "This application uses a machine learning model trained on emotional text data "
    "to predict the emotional intensity—whether it's Happiness, Angriness, or Sadness."
)

st.sidebar.header("🛠️ How to Use")
st.sidebar.write(
    "1. Type or paste a message in the text area.\n"
    "2. Click the 'Predict' button.\n"
    "3. View the predicted emotional intensity label with an emoji."
)
