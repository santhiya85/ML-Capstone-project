**Intensity Analysis (Build Your Own Model Using NLP and Python)**

## The objective of this project is to develop an intelligent Natural Language Processing (NLP) system capable of predicting emotional intensity from text reviews. The model classifies text into three emotional intensities: happiness, angriness, and sadness. This enables real-time feedback and insight into customer sentiments, helping organizations enhance user experience and engagement.

## **Data Overview**

## The dataset consists of text samples labeled with corresponding emotional intensities. Each entry contains a user-generated review and an intensity label. Preprocessing steps were applied to clean, standardize, and transform the text into usable input for machine learning models. The target variable indicates the emotional tone of the text: happiness, anger, or sadness.

## **Data Cleaning**

## Initial cleaning involved removing null or duplicate entries. Text normalization steps such as lowercasing, punctuation removal, stop word filtering, and lemmatization were applied to ensure uniform and meaningful textual data for analysis.

## **Exploratory Data Analysis (EDA)**

EDA was conducted to gain insights into word frequency, distribution of emotions, and text length patterns. Visualization tools such as count plots, word clouds, and pie charts were used to identify trends and ensure a balanced distribution of classes.

## **Feature Engineering**

## TF-IDF (Term Frequency-Inverse Document Frequency) was used to convert textual data into numerical vectors suitable for machine learning. Feature selection was performed using techniques like Chi-square analysis to retain the most informative terms for classification.

## **Model Training**  The dataset was split into training and test sets using an 80-20 ratio. All models were trained on the TF-IDF vectors, and GridSearchCV was used for hyperparameter tuning to optimize model accuracy and generalization.

## **Model Selection**  Three algorithms were evaluated for classification performance:

* ## **Logistic Regression:** A baseline model for linear classification. 

* ## **Random Forest:** An ensemble model that handles non-linear text features effectively. 

* ## **XGBoost:** A gradient boosting method known for high performance in NLP tasks.

## **Model Validation**

Model performance was evaluated using:

* Accuracy

* Precision

* Recall

* F1 Score

* Confusion Matrix

* ROC-AUC Score 

## **Dealing with Imbalanced Data**

To handle imbalance in class distribution, we used class weight adjustment during training and applied stratified splitting for train-test separation. These strategies improved the prediction of underrepresented classes like “angriness” and “sadness.”

## **Model Deployment**

The final Random Forest model, along with the TF-IDF vectorizer and feature selector, was saved using `joblib`. A Streamlit-based web interface was created to accept user input and display the predicted emotion in real-time, along with an emoji for better visualization.

# **How to Run**

**1\. Clone The Repository:**  
 

| git clone https://github.com/your-username/Intensity-Analysis.git cd Intensity-Analysis |
| :---- |

      
**2\.Install dependencies: Install the required Python packages using:**  
   

| pip install \-r requirements.txt |
| :---- |

**3\. Launch the App:**	

| streamlit run app.py |
| :---- |

**3\.Run the Jupyter Notebook: Launch Jupyter Notebook to view the analysis and model-building process:**

| jupyter notebook notebooks/Intensity-Analysis.ipynb  |
| :---- |

## **Conclusion:**

The Intensity Analysis project demonstrates how NLP techniques can be used to detect emotional tone from text reviews. Through preprocessing, feature extraction, and robust model training, the system effectively classifies text into three intensity levels. The model’s deployment through Streamlit allows for real-time prediction, making it a valuable tool for feedback analysis and customer interaction platforms.